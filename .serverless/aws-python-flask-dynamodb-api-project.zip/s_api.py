import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='allenwalkerd3',
    application_name='aws-python-flask-dynamodb-api-project',
    app_uid='Z1S4p7Rt8L9PBrswR9',
    org_uid='34255e8e-2543-4989-9ee0-921fe5437d76',
    deployment_uid='ff5cce69-0071-4092-8018-8451513c6a44',
    service_name='aws-python-flask-dynamodb-api-project',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.4.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-python-flask-dynamodb-api-project-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
